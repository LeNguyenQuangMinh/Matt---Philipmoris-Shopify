class FreeShippingComponent extends HTMLElement {
  constructor() {
    super();
  }

  static freeShippingText = window.free_shipping_text?.free_shipping_message || 'Free shipping for all orders over';
  static freeShippingText1 = window.free_shipping_text?.free_shipping_message_1 || 'You qualify for free shipping!';
  static freeShippingText2 = window.free_shipping_text?.free_shipping_message_2 || 'Spend';
  static freeShippingText3 = window.free_shipping_text?.free_shipping_message_3 || 'more to receive';
  static freeShippingText4 = window.free_shipping_text?.free_shipping_message_4 || 'free shipping';
  static classLabel1 = 'progress-30';
  static classLabel2 = 'progress-60';
  static classLabel3 = 'progress-100';
  static freeShippingPrice = window.free_shipping_price ? Currency.convert(parseInt(window.free_shipping_price), window.free_shipping_default_currency, Shopify.currency.active) : 0;

  connectedCallback() {
    this.freeShippingEligible = 0;
    this.progressBar = this.querySelector('[data-shipping-progress]');
    this.messageElement = this.querySelector('[data-shipping-message]');
    this.textEnabled = this.progressBar?.dataset.textEnabled === 'true';
    this.shipVal = window.free_shipping_text?.free_shipping_1;
    this.progressMeter = this.querySelector('[data-free-shipping-progress-meter]');
    this.onCartUpdated = () => this.initialize();

    document.addEventListener('cart:updated', this.onCartUpdated);

    if (typeof subscribe === 'function' && typeof PUB_SUB_EVENTS !== 'undefined') {
      this.cartUpdateUnsubscriber = subscribe(PUB_SUB_EVENTS.cartUpdate, this.onCartUpdated);
    }

    this.initialize();
    this.initOrderTimer();
  }

  disconnectedCallback() {
    document.removeEventListener('cart:updated', this.onCartUpdated);
    this.cartUpdateUnsubscriber?.();
    if (this.orderTimerId) {
      clearInterval(this.orderTimerId);
    }
  }

  initialize() {
    fetch('/cart.js')
      .then(response => response.json())
      .then(cart => {
        this.cart = cart;
        this.calculateProgress(cart);
      })
      .catch(error => {
        console.error('Error fetching cart:', error);
      });
  }

  onCartChange(e) {
    this.initialize();
  }

  calculateProgress(cart) {
    let totalPrice = cart.total_price;

    if (document.body.classList.contains('setup_shipping_delivery')) {
      const giftCardItems = document.querySelectorAll(".cart-item[data-price-gift-card], .previewCartItem[data-price-gift-card]");
      if (giftCardItems.length > 0) {
        giftCardItems.forEach(item => {
          totalPrice -= parseFloat(item.getAttribute("data-price-gift-card"));
        });
      }
    }

    const cartTotalPrice = parseInt(totalPrice) / 100;
    const cartTotalPriceFormatted = cartTotalPrice;
    const cartTotalPriceRounded = parseFloat(cartTotalPriceFormatted);

    let freeShipBar = FreeShippingComponent.freeShippingPrice > 0 ? Math.abs((cartTotalPriceRounded * 100) / FreeShippingComponent.freeShippingPrice) : 100;
    if (freeShipBar >= 100) {
      freeShipBar = 100;
    }

    const text = this.getText(cartTotalPriceFormatted, freeShipBar);
    const classLabel = this.getClassLabel(freeShipBar);

    this.setProgressWidthAndText(freeShipBar, text, classLabel);
  }

  getText(cartTotalPrice, freeShipBar) {
    let text;
    const isShowOnlyText = this.dataset.showOnlyText === 'true';

    if (isShowOnlyText) {
      const textBefore = this.dataset.textBefore || 'Spend';
      const textAfter = this.dataset.textAfter || 'more to receive free shipping';
      const textQualified = this.dataset.textQualified || FreeShippingComponent.freeShippingText1 || 'You qualify for free shipping!';

      if (cartTotalPrice == 0) {
        this.progressBar?.classList.add('progress-hidden');
        const formattedPrice = Shopify.formatMoney(FreeShippingComponent.freeShippingPrice.toFixed(2) * 100, window.money_format);
        text = `${textBefore} <span class="previewCart-shippingNotice-amount">${formattedPrice}</span> ${textAfter}`;
      } else if (cartTotalPrice >= FreeShippingComponent.freeShippingPrice) {
        this.progressBar?.classList.remove('progress-hidden');
        this.freeShippingEligible = 1;
        text = `<span class="previewCart-shippingNotice-eligible">${textQualified}</span>`;
      } else {
        this.progressBar?.classList.remove('progress-hidden');
        const remainingPrice = Math.abs(FreeShippingComponent.freeShippingPrice - cartTotalPrice);
        const formattedRemaining = Shopify.formatMoney(remainingPrice.toFixed(2) * 100, window.money_format);
        text = `${textBefore} <span class="previewCart-shippingNotice-amount">${formattedRemaining}</span> ${textAfter}`;
        this.shipVal = window.free_shipping_text?.free_shipping_2;
      }
    } else {
      if (cartTotalPrice == 0) {
        this.progressBar?.classList.add('progress-hidden');
        text = '<span>' + FreeShippingComponent.freeShippingText + ' ' + Shopify.formatMoney(FreeShippingComponent.freeShippingPrice.toFixed(2) * 100, window.money_format) + '!</span>';
      } else if (cartTotalPrice >= FreeShippingComponent.freeShippingPrice) {
        this.progressBar?.classList.remove('progress-hidden');
        this.freeShippingEligible = 1;
        text = FreeShippingComponent.freeShippingText1;
      } else {
        this.progressBar?.classList.remove('progress-hidden');
        const remainingPrice = Math.abs(FreeShippingComponent.freeShippingPrice - cartTotalPrice);
        text = '<span>' + FreeShippingComponent.freeShippingText2 + ' </span>' + Shopify.formatMoney(remainingPrice.toFixed(2) * 100, window.money_format) + '<span> ' + FreeShippingComponent.freeShippingText3 + ' </span><span class="text">' + FreeShippingComponent.freeShippingText4 + '</span>';
        this.shipVal = window.free_shipping_text?.free_shipping_2;
      }
    }

    return text;
  }

  getClassLabel(freeShipBar) {
    let classLabel;

    if (freeShipBar === 0) {
      classLabel = 'none';
    } else if (freeShipBar <= 30) {
      classLabel = FreeShippingComponent.classLabel1;
    } else if (freeShipBar <= 60) {
      classLabel = FreeShippingComponent.classLabel2;
    } else if (freeShipBar < 100) {
      classLabel = FreeShippingComponent.classLabel3;
    } else {
      classLabel = 'progress-free';
    }

    return classLabel;
  }

  resetProgressClass(classLabel) {
    if (!this.progressBar) return;
    this.progressBar.classList.remove('progress-30', 'progress-60', 'progress-100', 'progress-free');
    this.progressBar.classList.add(classLabel);
  }

  setProgressWidthAndText(freeShipBar, text, classLabel) {
    setTimeout(() => {
      if (!this.messageElement) return;

      this.resetProgressClass(classLabel);

      if (this.progressMeter) {
        this.progressMeter.style.width = `${freeShipBar}%`;

        if (this.textEnabled) {
          const textWrapper = this.progressMeter.querySelector('.text');
          if (textWrapper) {
            textWrapper.innerHTML = `${freeShipBar.toFixed(2)}%`;
          }
        }
      }

      this.messageElement.innerHTML = text;
    }, 400);
  }

  initOrderTimer() {
    const orderTimeSub = this.querySelector('[data-order-time-sub]');
    if (!orderTimeSub) return;

    const excludedDays = ['SAT', 'SUN'];
    const cutoffHour = 14;

    const updateTimer = () => {
      const now = new Date();
      const hours = now.getHours();
      const minutes = now.getMinutes();

      const weekday = now.toLocaleDateString('en-GB', { weekday: 'short' }).toUpperCase();
      if (excludedDays.includes(weekday)) {
        orderTimeSub.style.display = 'none';
        return false;
      }

      if (hours >= cutoffHour || (hours === 0 && minutes < 1)) {
        orderTimeSub.style.display = 'none';
        return false;
      }

      const cutoffTime = new Date(now);
      cutoffTime.setHours(cutoffHour, 0, 0, 0);

      const diffMs = cutoffTime - now;
      if (diffMs <= 0) {
        orderTimeSub.style.display = 'none';
        return false;
      }

      orderTimeSub.style.display = '';

      const diffHrs = Math.floor(diffMs / 3600000);
      const diffMins = Math.floor((diffMs % 3600000) / 60000);

      const hoursEl = orderTimeSub.querySelector('.hours');
      const minutesEl = orderTimeSub.querySelector('.minutes');

      if (hoursEl) hoursEl.textContent = String(diffHrs).padStart(2, '0');
      if (minutesEl) minutesEl.textContent = String(diffMins).padStart(2, '0');

      return true;
    };

    if (updateTimer()) {
      this.orderTimerId = setInterval(updateTimer, 1000);
    }
  }
}

window.addEventListener('load', () => {
  if (!customElements.get('free-shipping-component')) {
    customElements.define('free-shipping-component', FreeShippingComponent);
  }
});